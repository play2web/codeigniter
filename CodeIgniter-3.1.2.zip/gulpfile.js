﻿/// <binding ProjectOpened='watch-tasks' />
/*
This file in the main entry point for defining Gulp tasks and using Gulp plugins.
Click here to learn more. http://go.microsoft.com/fwlink/?LinkId=518007
*/

/* ---------------------------------------------
*    Load dependecies
*  ---------------------------------------------
*/
var gulp = require('gulp');
var mainBowerFiles = require('main-bower-files');
var realFavicon = require('gulp-real-favicon');
var fs = require('fs');
var watch = require('gulp-watch');
var less = require('gulp-less');
var autoprefixer = require('gulp-autoprefixer');
var minifyCSS = require('gulp-minify-css');
var cleanCSS = require('gulp-clean-css');
var notify = require('gulp-notify');
var gutil = require('gulp-util');
var uglify = require('gulp-uglify');
var concat = require('gulp-concat');
var ftp = require('vinyl-ftp');
var csso = require('gulp-csso');
//var imagemin = require('gulp-imagemin');
var browserSync = require('browser-sync').create();
var rename = require('gulp-rename');
var ignore = require('gulp-ignore');
var clean = require('gulp-clean');
var gulpIf = require('gulp-if');
var runSequence = require('run-sequence');
var htmlreplace = require('gulp-html-replace');
var replace = require('gulp-replace');


/* ---------------------------------------------
*    Load globals
*  ---------------------------------------------
*/

var paths = {
    thirdParty: "./scripts",
    bowerComponents: "./bower_components"
};

/* 1.0
* browserSync Tasks
* Click here to learn more. https://www.npmjs.com/package/browser-sync
* Keep multiple browsers & devices in sync when building websites.
*/

/// Reload task
gulp.task('browser-reload', function () {
    browserSync.reload();
});

/// Prepare Browser-sync for localhost 
gulp.task('browser-sync', function () {
    browserSync.init(['/*.css', 'scripts/*.js', 'views/**/*.html'], {
        proxy: 'http://localhost:9101'
    });
});

/* 2.0
* Minify depedencies JS
* Click here to learn more. https://www.npmjs.com/package/gulp-concat
* Proper order must be applied when adding new scripts
*/
gulp.task('minify-vendor-scripts', function () {
    return gulp.src([            
            './scripts/angular-img-http-src/index.js'

    ])
        .pipe(concat('vendor.scripts.js'))
        .pipe(gulp.dest('./scripts/'))
        .pipe(ignore.exclude(["*.map"]))
        .pipe(ignore.exclude(["*.map"]))
        .pipe(uglify().on('error', function (e) {
            console.log(e);
        }))
        .pipe(rename('vendor.scripts.min.js'))
        .pipe(gulp.dest('./scripts/'))
        .pipe(notify('Vendor scripts concated and minified'));
});

/* 3.0
*  Favicons tasks
*  Click here to learn more. https://www.npmjs.com/package/gulp-real-favicon
* Favicons are small square images usually 16×16 pixels which are used by web browsers to show a graphical 
* representation of the site being visited at the left side of the browser’s address bar. 
* You have probably seen many favicons before, even if you don’t know what they are. If there’s any doubt, the image below will help.
*/

// Generate the icons. This task takes a few seconds to complete. 
// You should run it at least once to create the icons. Then, 
// you should run it whenever RealFaviconGenerator updates its 
// package (see the check-for-favicon-update task below).
gulp.task('favicons-generate-icons', function (done) {

    var FAVICON_DATA_FILE = './content/images/favicons/faviconData.json';

    realFavicon.generateFavicon({
        masterPicture: './content/images/favicons/favicon.png',
        dest: '../content/images/favicons/',
        iconsPath: './content/images/favicons/',
        design: {
            ios: {
                pictureAspect: 'backgroundAndMargin',
                backgroundColor: '#ffffff',
                margin: '14%'
            },
            desktopBrowser: {},
            windows: {
                pictureAspect: 'noChange',
                backgroundColor: '#da532c',
                onConflict: 'override'
            },
            androidChrome: {
                pictureAspect: 'noChange',
                themeColor: '#ffffff',
                manifest: {
                    name: 'RMI',
                    display: 'browser',
                    orientation: 'notSet',
                    onConflict: 'override'
                }
            },
            safariPinnedTab: {
                pictureAspect: 'silhouette',
                themeColor: '#5bbad5'
            }
        },
        settings: {
            scalingAlgorithm: 'Mitchell',
            errorOnImageTooSmall: false
        },
        markupFile: FAVICON_DATA_FILE
    }, function () {
        done();
    });
});

// Check for facvicon updates schema
gulp.task('favicon-check-for-update', function (done) {
    var currentVersion = JSON.parse(fs.readFileSync(FAVICON_DATA_FILE)).version;
    realFavicon.checkForUpdates(currentVersion, function (err) {
        if (err) {
            throw err;
        }
    });
});


/* 4.0
*  LESS2CSS tasks
*  Click here to learn more. https://github.com/plus3network/gulp-less
*  Less is a CSS pre-processor, meaning that it extends the CSS language, adding features that allow variables, mixins, 
*  functions and many other techniques that allow you to make CSS that is more maintainable, themeable and extendable.
*/

gulp.task('less-compile', function () {
    var getPathCss = './content/less/';
    var compilePathCss = './content/css/';
    return gulp.src([getPathCss + 'styles.less']) // Your main less file
        .pipe(less({ compress: true }).on('error', gutil.log))
        .pipe(cleanCSS({ compatibility: 'ie8' }))
        .pipe(minifyCSS())
        .pipe(gulp.dest(compilePathCss))
          .pipe(csso({
              restructure: false,
              sourceMap: true,
              debug: true
          }))
        .pipe(notify('Less Compiled, Prefixed and Minified'));
});

/* 6.0
*  Main bower files tasks
*  Click here to learn more. https://github.com/ck86/main-bower-files
*  Use the bower.json file as the source and it will create a vinyl stream for 
* each of the files main-bower-files return when parsing the bower.json.
*/

gulp.task("main-bower-files", function copyMainBowerFilesToAssets() {
    return gulp.src(mainBowerFiles(), { base: paths.bowerComponents })
        .pipe(gulp.dest(paths.thirdParty))
        .pipe(notify('Files copied successfully'));
});


/* 7.0
*  Compress image size
*  Click here to learn more. https://github.com/imagemin/imagemin
*  uses a smart combination of the best optimization and lossy compression 
*  algorithms to shrink JPEG and PNG images to the minimum possible 
*  size while keeping the required level of quality.
*/
//gulp.task('compress-images', function () {
//    gulp.src('./img/**/*{css,png,jpg,gif}')
//        .pipe(imagemin())
//        .pipe(gulp.dest('./img'));
//});


/* 8.0
*  Clean unnecessary files
*  Click here to learn more. https://github.com/imagemin/imagemin
*  The first thing any self-respecting build system should do is clean the space and remove everything that's in the way.
*/
gulp.task('clean-unnecessary-files', function () {
    return gulp.src(['/**/*.js', '/**/*.js.map'], { read: false })
      .pipe(clean());
});


/* 9.0
*  Replace line of blocks in HTML files
*  Click here to learn more. https://www.npmjs.com/package/gulp-html-replace
*  Replace build blocks in HTML. Like useref but done right.
*/
gulp.task('replace-blocks-html', function () {
    gulp.src('./dist/index.html')
      .pipe(htmlreplace({
          'vendor': 'scripts/vendor.scripts.min.js',
          'app': 'scripts/app.min.js'
      }))
      .pipe(gulp.dest('./dist'));
});


/* 11.0
*  FTP prepare task
*  Click here to learn more. https://www.npmjs.com/package/vinyl-ftp
*  Blazing fast vinyl adapter for FTP. Supports parallel transfers, 
*  conditional transfers, buffered or streamed files, and more. Often performs 
*  better than your favorite desktop FTP client
*/
gulp.task('ftp-deploy', function () {

    var conn = ftp.create({
        host: '',
        user: '',
        password: '',
        parallel: 10,
        log: gutil.log
    });

    var globs = [
          './css/**/*{css,png,jpg,gif,ttf,woff,eof,svg,woff2}',
          './img/**',
          './fonts/**',
          './views/**',
          './scripts/vendor.scripts.min.js',
          './scripts/angular-ui-grid/ui-grid.min.js',
          './dist/index.html',
          './dist/app.min.js',
          'Web.config'
    ];

    return gulp.src(globs, { base: '.', buffer: false })
        .pipe(gulpIf('dist/index.html', rename({ dirname: '' })))
        .pipe(gulpIf('dist/app.min.js', rename({ dirname: '/scripts' })))
        .pipe(conn.newer('/site/wwwroot'))
        .pipe(conn.dest('/site/wwwroot'));
});


/* 12.0
*  Watch tasks
*  Click here to learn more. https://www.npmjs.com/package/gulp-watch
*  Watch is part of the API of gulp. It will watch files for changes, 
*  addition or deletion and trigger tasks.
*/
gulp.task('watch-tasks', function () {
    gulp.watch('./content/less/*.less', ['less-compile']); // Watch all the .less files, then run the less task
});


/* 13.0
*  FTP Deploy to some enviroment
*  Click here to learn more. https://www.npmjs.com/package/run-sequence
*  Runs a sequence of gulp tasks in the specified order. This function is designed to solve the 
*  situation where you have defined run-order, but choose not to or cannot use dependencies.
*/
gulp.task('ftp-deploy-test-enviroment', function (cb) {
    runSequence('minify-html', 'replace-blocks-html', 'replace-vars-js', 'ftp-deploy', cb);
});


/* 14.0
*  Error Handling
*  Click here to learn more. https://www.npmjs.com/package/gulp-plumber
*  Will prevent Gulp breaking caused by errors.
*/
var onError = function (err) {
    console.log('An error occurred:', gutil.colors.magenta(err.message));
    gutil.beep();
    this.emit('end');
};