var gulp = require('gulp');
var fs = require('fs');
var gutil = require('gulp-util');
var uglify = require('gulp-uglify');
var concat = require('gulp-concat');

var configuration = {
    typeScriptFiles: ['typescript/**/*.ts', '!typescript/typings/**/*.ts'],
    javaScriptFiles: ['typescript/**/*.js', '!typescript/typings/**/*.ts']
};

var paths = {
    thirdParty: "./scripts",
    bowerComponents: "./bower_components"
};
// Proper order must be applied when adding new scripts
gulp.task('minifyScripts', function () {
    return gulp.src([
            './scripts/angular/angular.js', 
            './scripts/angular-ui-router/release/angular-ui-router.js',
            './scripts/angular-animate/angular-animate.js',
            './scripts/angular-bootstrap/ui-bootstrap-tpls.js',
            './scripts/angular-resource/angular-resource.js',
            './scripts/angular-translate/angular-translate.js',
            './scripts/angular-translate-loader-url/angular-translate-loader-url.js',
            './scripts/ng-tags-input/ng-tags-input.js'
    ])
        .pipe(concat('vendor.scripts.min.js'))
        .pipe(uglify())
        .pipe(gulp.dest('./scripts/'));
});

gulp.task('app-bundle', function () {
    return gulp.src(configuration.javaScriptFiles)
        .pipe(concat('app.js'))
        .pipe(gulp.dest(paths.thirdParty))
        .pipe(ignore.exclude(["*.map"]))
        .pipe(uglify().on('error', function (e) {
            console.log(e);
        }))
        .pipe(rename('app.min.js'))
        .pipe(gulp.dest(paths.thirdParty))
        .on('error', gutil.log);
});