<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class MY_Controller extends CI_Controller {
	
	var $data;
	
	function __construct()
	{
		parent::__construct();
		
			$this->load->library('pagination');				
     		$data= $this->uri->uri_string();
			$arr=explode('/', $data);
			array_shift($arr);
			$uri=implode('/',$arr);		
			$this->smarty->assign("languages",array("en","de"));

		if (!$this->session->userdata('logged_in')){ 
            redirect(base_url());
        }
										
		if ($this->uri->segment(1) == 'de'){			
			$this->lang->load('label', 'deutsche');
			$this->smarty->assign("lang", "deutsche");
			$this->db->db_select('db_icefyre_de');
		}
		else{			
			// english is the default if you don't set lang
			$this->lang->load('label', 'english');
			$this->smarty->assign("lang", "english");
			$this->db->db_select('db_icefyre_en');
		}		
		
		$navigation = $this->navigation->menu_navigation();		
		$this->smarty->assign("navigation", $navigation);
		$this->smarty->assign("baseUrl", base_url());
		$this->smarty->assign("currentUrl", current_url());		
		$this->smarty->assign("currentUrlNoLang", $uri);
		$this->smarty->assign("sitename", $this->config->item('site_name'));
	}
}
