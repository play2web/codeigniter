<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	$config['cur_tag_open'] = '<li><span class="page active">';
	$config['cur_tag_close'] = '</span></li>';
	$config['num_tag_open'] = '<li class="page gradient">';
	$config['num_tag_close'] = '</li>';
	$config['prev_link'] = '&lt; prev';
	$config['prev_tag_open'] = ' <li class="page gradient">';
	$config['prev_tag_close'] = '</li>';
	$config['next_link'] = 'next &gt;';
	$config['next_tag_open'] = '<li class="page gradient">';
	$config['next_tag_close'] = '</li>';
	$config["per_page"] = 4;
