<?php
defined('BASEPATH') OR exit('No direct script access allowed');
Class Databasemanager extends CI_Model
{
	
    public function record_count($table) {
        return $this-> db -> count_all($table);
    }
	
    public function getAllLimit($limit, $start, $table) {
        $this->  db -> limit($limit, $start);	
		$query = $this -> db -> get($table);
		
        if($query -> num_rows() > 0) {
			return $query->result_array();
		}
		else {
			return false;
		}		
   }
   
	public function getAll($table) {
		$query = $this -> db -> get($table);
 
		if($query -> num_rows() == 1) {
			return $query->result_array();
		}
		else {
			return false;
		}
	}
	
	public function get_all_products($limit, $start, $table) { 
		$this->db->select('productId, productName, productDescription, productPicture, productSubText, productTaxonomie, productDateTime,  isbnNumber, productIsbn, taxonomieName, taxonomieDescription');
		$this->db->from($table);
		$this->db->join('Isbn', 'productIsbn = isbnId', 'left');
		$this->db->join('Taxonomies', 'productTaxonomie = taxonomieId', 'left');
		$this->db->limit($limit, $start);	
		$query = $this->db->get();
			
		if($query -> num_rows() > 0) {
			return $query->result_array();
		}
		else {
			show_404();
		}	
	}
	
	public function get_product($table, $id) { 
		$this->db->select('productId, productName, productDescription, productPicture, productSubText, productTaxonomie, productDateTime,  productPicture, isbnNumber, productIsbn, taxonomieName, taxonomieDescription, taxonomieId');
		$this->db->from($table);
		$this->db->join('Isbn', 'productIsbn = isbnId', 'left');
		$this->db->join('Taxonomies', 'productTaxonomie = taxonomieId', 'left');
		$this->db->where('isbnNumber', $id);		
		$query = $this->db->get();
			
		if($query -> num_rows() > 0) {
			return $query->result_array();
		}
		else {
			show_404();
		}	
	}
	
	public function get_category_products($limit, $start, $table, $id) { 
		$this->db->select('productId, productName, productDescription, productPicture, productSubText, productTaxonomie, productDateTime,  isbnNumber, productIsbn, taxonomieName, taxonomieDescription');
		$this->db->from($table);
		$this->db->join('Isbn', 'productIsbn = isbnId', 'left');
		$this->db->join('Taxonomies', 'productTaxonomie = taxonomieId', 'left');
		$this->db->where('productTaxonomie', $id);	
		$this->db->limit($limit, $start);			
		$query = $this->db->get();
			
		if($query -> num_rows() > 0) {
			return $query->result_array();
		}
		else {
			show_404();
		}	
	}
	
	public function get_record_count_category_products($table, $id) { 
		$this->db->select('productId, productName, productDescription, productPicture, productSubText, productTaxonomie, productDateTime,  isbnNumber, productIsbn, taxonomieName');
		$this->db->from($table);
		$this->db->join('Isbn', 'productIsbn = isbnId', 'left');
		$this->db->join('Taxonomies', 'productTaxonomie = taxonomieId', 'left');
		$this->db->where('productTaxonomie', $id);				
		$query = $this->db->get();
			
		if($query -> num_rows() > 0) {
			return $query->num_rows();
		}
		else {
			show_404();
		}	
	}
}