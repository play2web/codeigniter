<?php
defined('BASEPATH') OR exit('No direct script access allowed');
Class Navigation extends CI_Model
{
		function menu_navigation(){
			$menu = array(
			array('text' => $this->lang->line('home'), 'url' => ''),
			array('text' => $this->lang->line('aboutus'), 'url' => ''),
			array('text' => $this->lang->line('categories'), 'url' => '/'.$this->lang->line('culture').$this->lang->line('categoriesLink').'.html'),
			array('text' => $this->lang->line('references'), 'url' => ''),
			array('text' => $this->lang->line('contact'), 'url' => '')
			);			
			return $menu;				
		}
}