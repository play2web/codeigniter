<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Categories extends MY_Controller {

	function __construct()
	{
		parent::__construct();	
		
		// Default values
		$languageSelect = true;		
		
		// Breadcrumbs
		$this->breadcrumbs->push($this->lang->line('home'), '/'.$this->lang->line('culture').$this->lang->line('categoriesLink'));
		$this->breadcrumbs->push($this->lang->line('categories'), '/'.$this->lang->line('culture').$this->lang->line('categoriesLink'));
		$breadCrumbs = $this->breadcrumbs->show();
		
		// Assign values to smarty
		$this->smarty->assign("languageSelect", $languageSelect);
		$this->smarty->assign("breadCrumbs", $breadCrumbs);
		$this->smarty->assign("activeLink", $this->lang->line('categories'));
		$this->smarty->assign("pagetitle", $this->lang->line('categories'));
		$this->smarty->assign("description", $this->lang->line('categoriesDescription'));

	}

	function index()
	{
        $data = array();
		$table = 'Taxonomies';
		
		// Database query
		$config = array();
        $config["base_url"] = base_url() . '/'.$this->lang->line('culture').'/categories/';
        $config["total_rows"] = $this->databasemanager->record_count($table);
        $config["per_page"] = 2;
        $config["uri_segment"] = 3;
        $this->pagination->initialize($config);
		
        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		
        $data["categories"] = $this->databasemanager->
            getAllLimit($config["per_page"], $page, $table);	
			
		$data["base_url"] = base_url();	
        $data["links"] = $this->pagination->create_links();
	
		// Calling the convenience function view() that allows passing data
		$this->smarty->view('categories.tpl',$data);
		
	}
}
