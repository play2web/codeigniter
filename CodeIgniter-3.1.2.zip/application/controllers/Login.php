<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

	function __construct() {
		parent::__construct();
			
		// Default values
		$languageSelect = false;	
		$navigation = false;
		$this->lang->load('label', 'english');		
		
		// Breadcrumbs
		$breadCrumbs = false;
		
		// Assign values to smarty
		$this->smarty->assign("lang", "english");
		$this->smarty->assign("sitename", $this->config->item('site_name'));
		$this->smarty->assign("pagetitle", $this->lang->line('login'));
		$this->smarty->assign("description", $this->lang->line('sitedescription'));
		$this->smarty->assign("baseUrl", base_url());
		$this->smarty->assign("currentUrl", current_url());		
		$this->smarty->assign("languageSelect", $languageSelect);
		$this->smarty->assign("breadCrumbs", $breadCrumbs);	
	}

	function index() {		
		 // Calling the convenience function view() that allows passing data
		$this->smarty->view('login.tpl');
	}

	function validate_login() {
		
		$this->form_validation->set_rules('username', 'Username', 'trim|required');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|callback_check_database');

			if($this->form_validation->run() == FALSE) {
				//Field validation failed.  User redirected to login page
				$this->smarty->assign("error", $this->lang->line('invalidlogin'));
				 // Calling the convenience function view() that allows passing data
				$this->smarty->view('login.tpl');
			}
			else {
				//Go to private area
				redirect('en/categories', 'refresh');
			}
	}
	
	function check_database($password) {
		//Field validation succeeded.  Validate against database
		$username = $this->input->post('username');

		// Database query
		$result = $this->user->login($username, $password);

		if($result) {
			$sess_array = array();
			foreach($result as $row) {
				$sess_array = array(
					'id' => $row->id,
					'username' => $row->username
				);
				$this->session->set_userdata('logged_in', $sess_array);
			}
			return TRUE;
		}
		else {
			return false;
		}
	}

}