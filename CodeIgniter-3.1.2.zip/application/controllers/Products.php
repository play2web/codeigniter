<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Products extends MY_Controller {

	function __construct()
	{
		parent::__construct();		
		
		// Default values
		$languageSelect = true;	
		
		// Breadcrumbs
		$this->breadcrumbs->push($this->lang->line('home'), '/'.$this->lang->line('culture').$this->lang->line('categoriesLink'));
		$this->breadcrumbs->push($this->lang->line('categories'), '/'.$this->lang->line('culture').$this->lang->line('categoriesLink'));
		
		// Assign values to smarty
	    $this->smarty->assign("languageSelect", $languageSelect);
		$this->smarty->assign("activeLink", $this->lang->line('categories'));
	}

	function index()
	{
        $data = array();
		$table = 'Products';
		
		// Database query
		$config = array();
        $config["base_url"] = base_url() . '/'.$this->lang->line('culture').'/category/'.$this->uri->segment(3).'/'.$this->uri->segment(4).'/';
        $config["total_rows"] = $this->databasemanager->get_record_count_category_products($table, $this->uri->segment(4));
        $config["per_page"] = 2;
        $config["uri_segment"] = 5;
        $this->pagination->initialize($config);
		
        $page = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
		
        $data["products"] = $this->databasemanager->
            get_category_products($config["per_page"], $page, $table, $this->uri->segment(4));
		
		$data["base_url"] = base_url();
        $data["links"] = $this->pagination->create_links();
		
		// Breadcrumbs
		$this->breadcrumbs->push($data['products'][0]['taxonomieName'], '#');	
		$breadCrumbs = $this->breadcrumbs->show();
		
		// Assign values to smarty
		$this->smarty->assign("breadCrumbs", $breadCrumbs);	
		$this->smarty->assign("pagetitle", $data['products'][0]['taxonomieName']);
		$this->smarty->assign("description", $data['products'][0]['taxonomieDescription']);
		
		// Calling the convenience function view() that allows passing data
		$this->smarty->view('products.tpl',$data);
	}
}
