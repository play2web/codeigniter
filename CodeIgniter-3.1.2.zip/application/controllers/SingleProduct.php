<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class SingleProduct extends MY_Controller {

	function __construct()
	{
		parent::__construct();	
		// Default values
		$languageSelect = true;	
		
		// Breadcrumbs
		$this->breadcrumbs->push($this->lang->line('home'), '/'.$this->lang->line('culture').$this->lang->line('categoriesLink'));
		$this->breadcrumbs->push($this->lang->line('categories'), '/'.$this->lang->line('culture').$this->lang->line('categoriesLink'));
		
		// Assign values to smarty
	    $this->smarty->assign("languageSelect", $languageSelect);
		$this->smarty->assign("activeLink", $this->lang->line('categories'));
	}

	function index()
	{
        $data = array();	
		$table = 'Products';
		
    	// Database query
        $data["product"] = $this->databasemanager->get_product($table, $this->uri->segment(3));
		$data["relatedproducts"] = $this->databasemanager->get_category_products(4, 0, $table, $data['product'][0]['taxonomieId']);
		
		// Breadcrumbs		
		$this->breadcrumbs->push($data['product'][0]['taxonomieName'], $this->lang->line('culture').'/category/'.url_title($data['product'][0]['taxonomieName'], '-', TRUE).'/'.$data['product'][0]['taxonomieId']);	
		$this->breadcrumbs->push($data['product'][0]['productName'], '#');	
		$breadCrumbs = $this->breadcrumbs->show();
		
		// Assign values to smarty
		$this->smarty->assign("breadCrumbs", $breadCrumbs);	
		$this->smarty->assign("pagetitle", $data['product'][0]['productName']);
		$this->smarty->assign("description", $data['product'][0]['productDescription']);
		
		// Calling the convenience function view() that allows passing data
		$this->smarty->view('single_product.tpl',$data);
	}
}
